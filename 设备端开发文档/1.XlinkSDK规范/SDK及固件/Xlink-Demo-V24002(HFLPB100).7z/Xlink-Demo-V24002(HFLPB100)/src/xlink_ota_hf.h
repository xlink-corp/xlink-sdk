/*
 * xlink_ota_hf.h
 *
 *  Created on: 2015年9月12日
 *      Author: XT800
 */

#ifndef XLINK_OTA_HF_H_
#define XLINK_OTA_HF_H_

#include "xlink_system.h"

extern int USER_FUNC xlink_update_as_http(char *purl,char *type);

#endif /* XLINK_OTA_HF_H_ */
